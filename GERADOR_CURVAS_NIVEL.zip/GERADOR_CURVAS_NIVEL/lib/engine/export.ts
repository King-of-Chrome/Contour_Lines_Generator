import type { ContourParams } from "@/lib/store";
import type { Palette } from "@/lib/store";
import { runPipeline, scaleContours } from "./pipeline";

type Point = [number, number];

function polylineToSvgPath(points: Point[]): string {
  if (points.length < 2) return "";
  let d = `M${points[0][0].toFixed(2)},${points[0][1].toFixed(2)}`;
  for (let i = 1; i < points.length; i++) {
    d += ` L${points[i][0].toFixed(2)},${points[i][1].toFixed(2)}`;
  }
  return d;
}

export function exportSVG(
  params: ContourParams,
  palette: Palette,
  width: number,
  height: number,
): string {
  const result = runPipeline(params, width, height);
  const scaled = scaleContours(
    result.contours,
    result.fieldWidth,
    result.fieldHeight,
    width,
    height,
  );

  const levelArray = result.levels;
  const strokeColors = palette.strokes;

  let paths = "";

  for (let li = 0; li < levelArray.length; li++) {
    const level = levelArray[li];
    const polylines = scaled.get(level);
    if (!polylines) continue;

    const colorIndex = li % strokeColors.length;
    const depth = li / levelArray.length;
    const lineWidth =
      params.style.strokeWidth + params.style.strokeWidthVar * (1 - depth);
    const opacity = params.style.opacity * (0.5 + 0.5 * depth);

    for (const line of polylines) {
      const d = polylineToSvgPath(line);
      if (!d) continue;
      paths += `  <path d="${d}" fill="none" stroke="${strokeColors[colorIndex]}" stroke-width="${lineWidth.toFixed(2)}" stroke-opacity="${opacity.toFixed(2)}" stroke-linecap="round" stroke-linejoin="round"/>\n`;
    }
  }

  return `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${width} ${height}" width="${width}" height="${height}">
  <rect width="${width}" height="${height}" fill="${palette.background}"/>
${paths}</svg>`;
}

export function exportPNG(
  canvas: HTMLCanvasElement,
  filename: string,
): void {
  canvas.toBlob((blob) => {
    if (!blob) return;
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  }, "image/png");
}

export function downloadSVG(svgString: string, filename: string): void {
  const blob = new Blob([svgString], { type: "image/svg+xml" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}
