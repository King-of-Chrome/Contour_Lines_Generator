// Marching Squares contour extraction

type Point = [number, number];

function lerp(a: number, b: number, t: number): number {
  return a + (b - a) * t;
}

function interpolate(
  x1: number, y1: number, v1: number,
  x2: number, y2: number, v2: number,
  threshold: number,
): Point {
  const dv = v2 - v1;
  const t = Math.abs(dv) < 0.0001 ? 0.5 : (threshold - v1) / dv;
  return [lerp(x1, x2, t), lerp(y1, y2, t)];
}

export function extractContours(
  heightfield: Float32Array,
  width: number,
  height: number,
  levels: number[],
): Map<number, Point[][]> {
  const result = new Map<number, Point[][]>();

  for (const threshold of levels) {
    const segments: [Point, Point][] = [];

    for (let y = 0; y < height - 1; y++) {
      for (let x = 0; x < width - 1; x++) {
        const tl = heightfield[y * width + x];
        const tr = heightfield[y * width + x + 1];
        const br = heightfield[(y + 1) * width + x + 1];
        const bl = heightfield[(y + 1) * width + x];

        let caseIndex = 0;
        if (tl >= threshold) caseIndex |= 8;
        if (tr >= threshold) caseIndex |= 4;
        if (br >= threshold) caseIndex |= 2;
        if (bl >= threshold) caseIndex |= 1;

        if (caseIndex === 0 || caseIndex === 15) continue;

        // Edge midpoints (with interpolation)
        const top = interpolate(x, y, tl, x + 1, y, tr, threshold);
        const right = interpolate(x + 1, y, tr, x + 1, y + 1, br, threshold);
        const bottom = interpolate(x, y + 1, bl, x + 1, y + 1, br, threshold);
        const left = interpolate(x, y, tl, x, y + 1, bl, threshold);

        switch (caseIndex) {
          case 1: segments.push([left, bottom]); break;
          case 2: segments.push([bottom, right]); break;
          case 3: segments.push([left, right]); break;
          case 4: segments.push([top, right]); break;
          case 5:
            // Saddle point
            segments.push([top, left]);
            segments.push([bottom, right]);
            break;
          case 6: segments.push([top, bottom]); break;
          case 7: segments.push([top, left]); break;
          case 8: segments.push([top, left]); break;
          case 9: segments.push([top, bottom]); break;
          case 10:
            // Saddle point
            segments.push([top, right]);
            segments.push([left, bottom]);
            break;
          case 11: segments.push([top, right]); break;
          case 12: segments.push([left, right]); break;
          case 13: segments.push([bottom, right]); break;
          case 14: segments.push([left, bottom]); break;
        }
      }
    }

    // Chain segments into polylines
    const polylines = chainSegments(segments);
    result.set(threshold, polylines);
  }

  return result;
}

function pointKey(p: Point): string {
  // Round to grid to snap close points together
  return `${(p[0] * 100 + 0.5) | 0},${(p[1] * 100 + 0.5) | 0}`;
}

function chainSegments(segments: [Point, Point][]): Point[][] {
  if (segments.length === 0) return [];

  // Build adjacency using a hash map for O(n) chaining
  const adj = new Map<string, { point: Point; neighbor: Point; idx: number }[]>();

  for (let i = 0; i < segments.length; i++) {
    const [a, b] = segments[i];
    const ka = pointKey(a);
    const kb = pointKey(b);
    if (!adj.has(ka)) adj.set(ka, []);
    if (!adj.has(kb)) adj.set(kb, []);
    adj.get(ka)!.push({ point: a, neighbor: b, idx: i });
    adj.get(kb)!.push({ point: b, neighbor: a, idx: i });
  }

  const used = new Set<number>();
  const polylines: Point[][] = [];

  for (let i = 0; i < segments.length; i++) {
    if (used.has(i)) continue;
    used.add(i);

    const line: Point[] = [segments[i][0], segments[i][1]];

    // Extend tail
    let extending = true;
    while (extending) {
      extending = false;
      const tailKey = pointKey(line[line.length - 1]);
      const candidates = adj.get(tailKey);
      if (candidates) {
        for (const c of candidates) {
          if (!used.has(c.idx)) {
            used.add(c.idx);
            // Determine which end of this segment connects
            if (pointKey(c.point) === tailKey) {
              line.push(c.neighbor);
            } else {
              line.push(c.point);
            }
            extending = true;
            break;
          }
        }
      }
    }

    // Extend head
    extending = true;
    while (extending) {
      extending = false;
      const headKey = pointKey(line[0]);
      const candidates = adj.get(headKey);
      if (candidates) {
        for (const c of candidates) {
          if (!used.has(c.idx)) {
            used.add(c.idx);
            if (pointKey(c.point) === headKey) {
              line.unshift(c.neighbor);
            } else {
              line.unshift(c.point);
            }
            extending = true;
            break;
          }
        }
      }
    }

    if (line.length >= 2) {
      polylines.push(line);
    }
  }

  return polylines;
}

export function generateLevels(count: number, step: number, offset: number): number[] {
  const levels: number[] = [];
  // Distribute levels evenly across the [0,1] range
  const spacing = step > 0.001 ? step : 1 / (count + 1);
  for (let i = 0; i < count; i++) {
    const level = offset + (i + 1) * spacing;
    if (level > 0.01 && level < 0.99) {
      levels.push(level);
    }
  }
  if (levels.length === 0) {
    // Fallback: generate evenly spaced levels
    for (let i = 1; i <= count; i++) {
      levels.push(i / (count + 1));
    }
  }
  return levels;
}
