import type { ContourParams } from "@/lib/store";
import { generateHeightfield } from "./noise";
import { extractContours, generateLevels } from "./contour";
import { processPolylines } from "./postprocess";

type Point = [number, number];

export type ContourResult = {
  levels: number[];
  contours: Map<number, Point[][]>;
  heightfield: Float32Array;
  fieldWidth: number;
  fieldHeight: number;
};

const FIELD_RESOLUTION = 150;

export function runPipeline(
  params: ContourParams,
  canvasWidth: number,
  canvasHeight: number,
): ContourResult {
  const aspect = canvasWidth / canvasHeight;
  const fieldWidth = FIELD_RESOLUTION;
  const fieldHeight = Math.round(FIELD_RESOLUTION / aspect);

  // Step 1: Generate heightfield
  const heightfield = generateHeightfield(
    fieldWidth,
    fieldHeight,
    params.source.seed,
    params.source.scale,
    params.source.warp,
    params.source.gain,
    params.source.lacunarity,
    params.source.octaves,
  );

  // Step 2: Generate contour levels
  const levels = generateLevels(
    params.contours.count,
    params.contours.step,
    params.contours.offset,
  );

  // Step 3: Extract contours (marching squares)
  const rawContours = extractContours(heightfield, fieldWidth, fieldHeight, levels);

  // Step 4: Post-process (simplify, smooth, chamfer)
  const contours = processPolylines(
    rawContours,
    params.geometry.simplify,
    params.geometry.smooth,
    params.geometry.chamfer,
    params.geometry.chamferAngle,
  );

  return { levels, contours, heightfield, fieldWidth, fieldHeight };
}

// Scale contour points from field coordinates to canvas coordinates
export function scaleContours(
  contours: Map<number, Point[][]>,
  fieldWidth: number,
  fieldHeight: number,
  canvasWidth: number,
  canvasHeight: number,
): Map<number, Point[][]> {
  const scaleX = canvasWidth / fieldWidth;
  const scaleY = canvasHeight / fieldHeight;
  const result = new Map<number, Point[][]>();

  for (const [level, polylines] of contours) {
    result.set(
      level,
      polylines.map((line) =>
        line.map((p) => [p[0] * scaleX, p[1] * scaleY] as Point),
      ),
    );
  }

  return result;
}
