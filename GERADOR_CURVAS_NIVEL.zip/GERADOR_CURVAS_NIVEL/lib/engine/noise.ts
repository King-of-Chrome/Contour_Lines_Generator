// Simplex noise implementation for heightfield generation

const F2 = 0.5 * (Math.sqrt(3) - 1);
const G2 = (3 - Math.sqrt(3)) / 6;

const grad3 = [
  [1, 1], [-1, 1], [1, -1], [-1, -1],
  [1, 0], [-1, 0], [0, 1], [0, -1],
];

function buildPermutation(seed: number): Uint8Array {
  const p = new Uint8Array(512);
  const base = new Uint8Array(256);
  for (let i = 0; i < 256; i++) base[i] = i;

  // Fisher-Yates seeded shuffle
  let s = seed;
  for (let i = 255; i > 0; i--) {
    s = (s * 16807 + 0) % 2147483647;
    const j = s % (i + 1);
    const tmp = base[i];
    base[i] = base[j];
    base[j] = tmp;
  }

  for (let i = 0; i < 512; i++) p[i] = base[i & 255];
  return p;
}

function simplex2D(x: number, y: number, perm: Uint8Array): number {
  const s = (x + y) * F2;
  const i = Math.floor(x + s);
  const j = Math.floor(y + s);
  const t = (i + j) * G2;
  const X0 = i - t;
  const Y0 = j - t;
  const x0 = x - X0;
  const y0 = y - Y0;

  let i1: number, j1: number;
  if (x0 > y0) { i1 = 1; j1 = 0; }
  else { i1 = 0; j1 = 1; }

  const x1 = x0 - i1 + G2;
  const y1 = y0 - j1 + G2;
  const x2 = x0 - 1 + 2 * G2;
  const y2 = y0 - 1 + 2 * G2;

  const ii = i & 255;
  const jj = j & 255;

  let n0 = 0, n1 = 0, n2 = 0;

  let t0 = 0.5 - x0 * x0 - y0 * y0;
  if (t0 > 0) {
    t0 *= t0;
    const gi0 = perm[ii + perm[jj]] % 8;
    n0 = t0 * t0 * (grad3[gi0][0] * x0 + grad3[gi0][1] * y0);
  }

  let t1 = 0.5 - x1 * x1 - y1 * y1;
  if (t1 > 0) {
    t1 *= t1;
    const gi1 = perm[ii + i1 + perm[jj + j1]] % 8;
    n1 = t1 * t1 * (grad3[gi1][0] * x1 + grad3[gi1][1] * y1);
  }

  let t2 = 0.5 - x2 * x2 - y2 * y2;
  if (t2 > 0) {
    t2 *= t2;
    const gi2 = perm[ii + 1 + perm[jj + 1]] % 8;
    n2 = t2 * t2 * (grad3[gi2][0] * x2 + grad3[gi2][1] * y2);
  }

  return 70 * (n0 + n1 + n2);
}

export function generateHeightfield(
  width: number,
  height: number,
  seed: number,
  scale: number,
  warp: number,
  gain: number,
  lacunarity: number,
  octaves: number,
): Float32Array {
  const perm = buildPermutation(seed);
  const permWarp = buildPermutation(seed + 1337);
  const data = new Float32Array(width * height);

  let minVal = Infinity;
  let maxVal = -Infinity;

  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      let nx = (x / width) * scale;
      let ny = (y / height) * scale;

      // Domain warping
      if (warp > 0) {
        const wx = simplex2D(nx + 5.2, ny + 1.3, permWarp) * warp;
        const wy = simplex2D(nx + 9.7, ny + 6.8, permWarp) * warp;
        nx += wx;
        ny += wy;
      }

      // FBM (Fractal Brownian Motion)
      let value = 0;
      let amplitude = 1;
      let frequency = 1;
      let maxAmp = 0;

      for (let o = 0; o < octaves; o++) {
        value += amplitude * simplex2D(nx * frequency, ny * frequency, perm);
        maxAmp += amplitude;
        amplitude *= gain;
        frequency *= lacunarity;
      }

      value = value / maxAmp;
      // Normalize from [-1,1] to [0,1]
      value = (value + 1) * 0.5;

      data[y * width + x] = value;
      if (value < minVal) minVal = value;
      if (value > maxVal) maxVal = value;
    }
  }

  // Normalize to full [0,1] range
  const range = maxVal - minVal || 1;
  for (let i = 0; i < data.length; i++) {
    data[i] = (data[i] - minVal) / range;
  }

  return data;
}
