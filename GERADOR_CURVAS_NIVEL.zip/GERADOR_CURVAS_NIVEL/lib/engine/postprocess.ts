// Post-processing: simplify, smooth, chamfer

type Point = [number, number];

// Ramer-Douglas-Peucker simplification
function perpendicularDistance(point: Point, lineStart: Point, lineEnd: Point): number {
  const dx = lineEnd[0] - lineStart[0];
  const dy = lineEnd[1] - lineStart[1];
  const lenSq = dx * dx + dy * dy;
  if (lenSq === 0) {
    const ddx = point[0] - lineStart[0];
    const ddy = point[1] - lineStart[1];
    return Math.sqrt(ddx * ddx + ddy * ddy);
  }
  const t = Math.max(0, Math.min(1, ((point[0] - lineStart[0]) * dx + (point[1] - lineStart[1]) * dy) / lenSq));
  const projX = lineStart[0] + t * dx;
  const projY = lineStart[1] + t * dy;
  return Math.sqrt((point[0] - projX) ** 2 + (point[1] - projY) ** 2);
}

function rdpSimplify(points: Point[], epsilon: number): Point[] {
  if (points.length <= 2) return points;

  let maxDist = 0;
  let maxIndex = 0;

  for (let i = 1; i < points.length - 1; i++) {
    const dist = perpendicularDistance(points[i], points[0], points[points.length - 1]);
    if (dist > maxDist) {
      maxDist = dist;
      maxIndex = i;
    }
  }

  if (maxDist > epsilon) {
    const left = rdpSimplify(points.slice(0, maxIndex + 1), epsilon);
    const right = rdpSimplify(points.slice(maxIndex), epsilon);
    return [...left.slice(0, -1), ...right];
  }

  return [points[0], points[points.length - 1]];
}

// Chaikin corner-cutting smoothing
function chaikinSmooth(points: Point[], iterations: number): Point[] {
  if (points.length < 3 || iterations <= 0) return points;

  let result = points;

  for (let iter = 0; iter < iterations; iter++) {
    const newPoints: Point[] = [result[0]];

    for (let i = 0; i < result.length - 1; i++) {
      const p0 = result[i];
      const p1 = result[i + 1];
      const q: Point = [
        0.75 * p0[0] + 0.25 * p1[0],
        0.75 * p0[1] + 0.25 * p1[1],
      ];
      const r: Point = [
        0.25 * p0[0] + 0.75 * p1[0],
        0.25 * p0[1] + 0.75 * p1[1],
      ];
      newPoints.push(q, r);
    }

    newPoints.push(result[result.length - 1]);
    result = newPoints;
  }

  return result;
}

// Chamfer: cut corners at sharp angles
function angleBetween(a: Point, b: Point, c: Point): number {
  const v1x = a[0] - b[0];
  const v1y = a[1] - b[1];
  const v2x = c[0] - b[0];
  const v2y = c[1] - b[1];
  const dot = v1x * v2x + v1y * v2y;
  const cross = v1x * v2y - v1y * v2x;
  return Math.abs(Math.atan2(cross, dot)) * (180 / Math.PI);
}

function chamferPolyline(
  points: Point[],
  chamferAmount: number, // 0-100
  angleThreshold: number, // degrees - chamfer corners sharper than this
): Point[] {
  if (points.length < 3 || chamferAmount <= 0) return points;

  const d = chamferAmount * 0.006; // Max chamfer distance factor
  const result: Point[] = [points[0]];

  for (let i = 1; i < points.length - 1; i++) {
    const prev = points[i - 1];
    const curr = points[i];
    const next = points[i + 1];
    const angle = angleBetween(prev, curr, next);

    if (angle < angleThreshold) {
      // Apply chamfer: insert two points receded along the two edges
      const d1x = prev[0] - curr[0];
      const d1y = prev[1] - curr[1];
      const len1 = Math.sqrt(d1x * d1x + d1y * d1y) || 1;
      const d2x = next[0] - curr[0];
      const d2y = next[1] - curr[1];
      const len2 = Math.sqrt(d2x * d2x + d2y * d2y) || 1;

      const chamferDist = Math.min(d, len1 * 0.4, len2 * 0.4);

      const p1: Point = [
        curr[0] + (d1x / len1) * chamferDist,
        curr[1] + (d1y / len1) * chamferDist,
      ];
      const p2: Point = [
        curr[0] + (d2x / len2) * chamferDist,
        curr[1] + (d2y / len2) * chamferDist,
      ];

      result.push(p1, p2);
    } else {
      result.push(curr);
    }
  }

  result.push(points[points.length - 1]);
  return result;
}

export function processPolylines(
  contourMap: Map<number, Point[][]>,
  simplifyAmount: number, // 0-5 (epsilon)
  smoothAmount: number, // 0-100
  chamferAmount: number, // 0-100
  chamferAngle: number, // degrees threshold
): Map<number, Point[][]> {
  const result = new Map<number, Point[][]>();

  for (const [level, polylines] of contourMap) {
    const processed = polylines.map((line) => {
      // Step 1: Simplify
      let pts = simplifyAmount > 0.01 ? rdpSimplify(line, simplifyAmount) : line;

      // Step 2: Smooth
      if (smoothAmount > 0) {
        const iterations = Math.ceil(smoothAmount / 25);
        pts = chaikinSmooth(pts, iterations);
      }

      // Step 3: Chamfer
      if (chamferAmount > 0) {
        pts = chamferPolyline(pts, chamferAmount, chamferAngle);
      }

      return pts;
    });

    result.set(level, processed);
  }

  return result;
}
