import { create } from "zustand";

export type ContourParams = {
  source: {
    mode: "procedural";
    seed: number;
    scale: number;
    warp: number;
    gain: number;
    lacunarity: number;
    octaves: number;
  };
  contours: {
    count: number;
    step: number;
    offset: number;
  };
  geometry: {
    simplify: number;
    smooth: number;
    chamfer: number;
    chamferAngle: number;
  };
  style: {
    stroke: string;
    strokeWidth: number;
    strokeWidthVar: number;
    opacity: number;
    noise: number;
  };
};

export type Palette = {
  id: string;
  name: string;
  background: string;
  strokes: string[];
};

export const PALETTES: Palette[] = [
  {
    id: "mono",
    name: "Monochrome",
    background: "#0e1014",
    strokes: ["#e8e4dc", "#b8b4ac", "#88847c", "#58544c", "#38342c"],
  },
  {
    id: "olive",
    name: "Olive Terrain",
    background: "#0e1014",
    strokes: ["#8fa65c", "#6b8a3f", "#4e6e2a", "#3a5520", "#2a3d18"],
  },
  {
    id: "sand",
    name: "Desert Sand",
    background: "#1a1610",
    strokes: ["#d4a56a", "#b8874a", "#9c6a32", "#805020", "#644018"],
  },
  {
    id: "ocean",
    name: "Deep Ocean",
    background: "#0a0e14",
    strokes: ["#4a90b8", "#3a78a0", "#2a6088", "#1e4870", "#143458"],
  },
  {
    id: "fire",
    name: "Volcanic",
    background: "#140a08",
    strokes: ["#d45030", "#b83820", "#982818", "#781810", "#581008"],
  },
];

const DEFAULT_PARAMS: ContourParams = {
  source: {
    mode: "procedural",
    seed: 42,
    scale: 3.0,
    warp: 0.5,
    gain: 0.5,
    lacunarity: 2.0,
    octaves: 6,
  },
  contours: {
    count: 20,
    step: 0.05,
    offset: 0,
  },
  geometry: {
    simplify: 1.0,
    smooth: 50,
    chamfer: 30,
    chamferAngle: 120,
  },
  style: {
    stroke: "#e8e4dc",
    strokeWidth: 1.5,
    strokeWidthVar: 0.3,
    opacity: 0.85,
    noise: 0,
  },
};

export type Preset = {
  id: string;
  name: string;
  description: string;
  params: ContourParams;
  paletteId: string;
};

export const PRESETS: Preset[] = [
  {
    id: "jeep-topo-01",
    name: "Jeep Topo Classic",
    description: "Clean contour lines with subtle chamfering",
    params: { ...DEFAULT_PARAMS },
    paletteId: "mono",
  },
  {
    id: "jeep-topo-02",
    name: "Rugged Trail",
    description: "High warp, dense contours for rugged terrain",
    params: {
      ...DEFAULT_PARAMS,
      source: { ...DEFAULT_PARAMS.source, warp: 0.8, gain: 0.6, scale: 4.0 },
      contours: { ...DEFAULT_PARAMS.contours, count: 30 },
      geometry: { ...DEFAULT_PARAMS.geometry, smooth: 30, chamfer: 50 },
    },
    paletteId: "olive",
  },
  {
    id: "jeep-topo-03",
    name: "Desert Dunes",
    description: "Smooth, flowing lines evoking sand dunes",
    params: {
      ...DEFAULT_PARAMS,
      source: { ...DEFAULT_PARAMS.source, warp: 0.3, scale: 2.0, lacunarity: 1.8 },
      contours: { ...DEFAULT_PARAMS.contours, count: 15 },
      geometry: { ...DEFAULT_PARAMS.geometry, smooth: 80, chamfer: 10 },
    },
    paletteId: "sand",
  },
  {
    id: "jeep-topo-04",
    name: "Mountain Ridge",
    description: "Sharp, angular peaks with high chamfer",
    params: {
      ...DEFAULT_PARAMS,
      source: { ...DEFAULT_PARAMS.source, warp: 0.7, gain: 0.55, octaves: 8, scale: 5.0 },
      contours: { ...DEFAULT_PARAMS.contours, count: 25 },
      geometry: { ...DEFAULT_PARAMS.geometry, smooth: 20, chamfer: 70 },
    },
    paletteId: "mono",
  },
  {
    id: "jeep-topo-05",
    name: "Ocean Floor",
    description: "Deep, moody bathymetric contours",
    params: {
      ...DEFAULT_PARAMS,
      source: { ...DEFAULT_PARAMS.source, warp: 0.4, gain: 0.45, scale: 2.5 },
      contours: { ...DEFAULT_PARAMS.contours, count: 18 },
      geometry: { ...DEFAULT_PARAMS.geometry, smooth: 60, chamfer: 20 },
    },
    paletteId: "ocean",
  },
];

type HistoryEntry = {
  params: ContourParams;
  paletteId: string;
};

type EditorStore = {
  params: ContourParams;
  paletteId: string;
  canvasSize: { width: number; height: number };
  camera: { zoom: number; panX: number; panY: number };
  contourPaths: number[][][] | null;
  isGenerating: boolean;
  leftPanelOpen: boolean;
  rightPanelOpen: boolean;
  history: HistoryEntry[];
  historyIndex: number;

  setParam: <
    K extends keyof ContourParams,
    SK extends keyof ContourParams[K],
  >(
    category: K,
    key: SK,
    value: ContourParams[K][SK],
  ) => void;
  setPaletteId: (id: string) => void;
  setCamera: (camera: Partial<EditorStore["camera"]>) => void;
  setCanvasSize: (size: { width: number; height: number }) => void;
  setContourPaths: (paths: number[][][] | null) => void;
  setIsGenerating: (v: boolean) => void;
  toggleLeftPanel: () => void;
  toggleRightPanel: () => void;
  loadPreset: (preset: Preset) => void;
  randomizeSeed: () => void;
  undo: () => void;
  redo: () => void;
  pushHistory: () => void;
};

export const useEditorStore = create<EditorStore>((set, get) => ({
  params: DEFAULT_PARAMS,
  paletteId: "mono",
  canvasSize: { width: 800, height: 600 },
  camera: { zoom: 1, panX: 0, panY: 0 },
  contourPaths: null,
  isGenerating: false,
  leftPanelOpen: true,
  rightPanelOpen: true,
  history: [{ params: DEFAULT_PARAMS, paletteId: "mono" }],
  historyIndex: 0,

  setParam: (category, key, value) => {
    set((state) => ({
      params: {
        ...state.params,
        [category]: {
          ...state.params[category],
          [key]: value,
        },
      },
    }));
  },

  setPaletteId: (id) => set({ paletteId: id }),

  setCamera: (camera) =>
    set((state) => ({ camera: { ...state.camera, ...camera } })),

  setCanvasSize: (size) => set({ canvasSize: size }),

  setContourPaths: (paths) => set({ contourPaths: paths }),

  setIsGenerating: (v) => set({ isGenerating: v }),

  toggleLeftPanel: () => set((s) => ({ leftPanelOpen: !s.leftPanelOpen })),
  toggleRightPanel: () => set((s) => ({ rightPanelOpen: !s.rightPanelOpen })),

  loadPreset: (preset) => {
    const palette = PALETTES.find((p) => p.id === preset.paletteId);
    set({
      params: {
        ...preset.params,
        style: {
          ...preset.params.style,
          stroke: palette?.strokes[0] ?? preset.params.style.stroke,
        },
      },
      paletteId: preset.paletteId,
    });
    get().pushHistory();
  },

  randomizeSeed: () => {
    const newSeed = Math.floor(Math.random() * 100000);
    set((state) => ({
      params: {
        ...state.params,
        source: { ...state.params.source, seed: newSeed },
      },
    }));
    get().pushHistory();
  },

  undo: () => {
    const { history, historyIndex } = get();
    if (historyIndex > 0) {
      const newIndex = historyIndex - 1;
      const entry = history[newIndex];
      set({
        historyIndex: newIndex,
        params: entry.params,
        paletteId: entry.paletteId,
      });
    }
  },

  redo: () => {
    const { history, historyIndex } = get();
    if (historyIndex < history.length - 1) {
      const newIndex = historyIndex + 1;
      const entry = history[newIndex];
      set({
        historyIndex: newIndex,
        params: entry.params,
        paletteId: entry.paletteId,
      });
    }
  },

  pushHistory: () => {
    const { params, paletteId, history, historyIndex } = get();
    const newHistory = history.slice(0, historyIndex + 1);
    newHistory.push({ params: JSON.parse(JSON.stringify(params)), paletteId });
    if (newHistory.length > 50) newHistory.shift();
    set({ history: newHistory, historyIndex: newHistory.length - 1 });
  },
}));
