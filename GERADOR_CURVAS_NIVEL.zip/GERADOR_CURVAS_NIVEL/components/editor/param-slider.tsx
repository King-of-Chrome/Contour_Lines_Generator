"use client";

import { Slider } from "@/components/ui/slider";
import { useEditorStore } from "@/lib/store";
import type { ContourParams } from "@/lib/store";
import { useCallback, useRef, useState, useEffect } from "react";

type ParamSliderProps<
  K extends keyof ContourParams,
  SK extends keyof ContourParams[K],
> = {
  label: string;
  category: K;
  paramKey: SK;
  min: number;
  max: number;
  step: number;
  format?: (v: number) => string;
};

export function ParamSlider<
  K extends keyof ContourParams,
  SK extends keyof ContourParams[K],
>({
  label,
  category,
  paramKey,
  min,
  max,
  step,
  format,
}: ParamSliderProps<K, SK>) {
  const storeValue = useEditorStore((s) => s.params[category][paramKey]) as number;
  const setParam = useEditorStore((s) => s.setParam);
  const pushHistory = useEditorStore((s) => s.pushHistory);
  const commitTimeout = useRef<ReturnType<typeof setTimeout>>();

  // Use local state for smooth slider movement
  const [localValue, setLocalValue] = useState(storeValue);
  const isSliding = useRef(false);

  // Sync from store when not actively sliding
  useEffect(() => {
    if (!isSliding.current) {
      setLocalValue(storeValue);
    }
  }, [storeValue]);

  const handleChange = useCallback(
    (val: number[]) => {
      isSliding.current = true;
      const newVal = val[0];
      setLocalValue(newVal);

      // Debounce the store update for smooth UI
      clearTimeout(commitTimeout.current);
      commitTimeout.current = setTimeout(() => {
        setParam(category, paramKey, newVal as ContourParams[K][SK]);
        isSliding.current = false;
      }, 60);
    },
    [setParam, category, paramKey],
  );

  const handleCommit = useCallback(
    (val: number[]) => {
      // Final commit when user finishes dragging
      clearTimeout(commitTimeout.current);
      isSliding.current = false;
      setParam(category, paramKey, val[0] as ContourParams[K][SK]);
      pushHistory();
    },
    [setParam, pushHistory, category, paramKey],
  );

  const displayValue = format
    ? format(localValue)
    : localValue.toFixed(step < 1 ? 2 : 0);

  return (
    <div className="flex flex-col gap-1.5">
      <div className="flex items-center justify-between">
        <label className="text-xs font-medium text-muted-foreground">
          {label}
        </label>
        <span className="text-xs font-mono text-foreground/70 tabular-nums">
          {displayValue}
        </span>
      </div>
      <Slider
        value={[localValue]}
        onValueChange={handleChange}
        onValueCommit={handleCommit}
        min={min}
        max={max}
        step={step}
        className="w-full"
      />
    </div>
  );
}
