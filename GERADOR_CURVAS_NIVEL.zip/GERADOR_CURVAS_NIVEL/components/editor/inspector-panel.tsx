"use client";

import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { ParamSlider } from "./param-slider";
import { PaletteSelector } from "./palette-selector";
import { useEditorStore } from "@/lib/store";
import { Shuffle } from "lucide-react";
import { Button } from "@/components/ui/button";

function SectionHeader({ title }: { title: string }) {
  return (
    <h3 className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground/70 mb-2">
      {title}
    </h3>
  );
}

export function InspectorPanel() {
  const randomizeSeed = useEditorStore((s) => s.randomizeSeed);
  const seed = useEditorStore((s) => s.params.source.seed);

  return (
    <div className="flex flex-col h-full bg-card border-l border-border">
      <div className="flex items-center justify-between px-4 py-3 border-b border-border">
        <h2 className="text-sm font-semibold text-foreground">Inspector</h2>
      </div>

      <ScrollArea className="flex-1">
        <div className="flex flex-col gap-5 p-4">
          {/* Heightfield Source */}
          <section>
            <SectionHeader title="Heightfield" />
            <div className="flex flex-col gap-3">
              <div className="flex items-center justify-between">
                <span className="text-xs text-muted-foreground">
                  Seed: <span className="font-mono text-foreground/70">{seed}</span>
                </span>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={randomizeSeed}
                  className="h-7 px-2 text-xs text-muted-foreground hover:text-foreground"
                >
                  <Shuffle className="w-3.5 h-3.5 mr-1" />
                  Randomize
                </Button>
              </div>
              <ParamSlider
                label="Scale"
                category="source"
                paramKey="scale"
                min={0.5}
                max={10}
                step={0.1}
              />
              <ParamSlider
                label="Warp"
                category="source"
                paramKey="warp"
                min={0}
                max={2}
                step={0.01}
              />
              <ParamSlider
                label="Ruggedness (Gain)"
                category="source"
                paramKey="gain"
                min={0.1}
                max={0.9}
                step={0.01}
              />
              <ParamSlider
                label="Lacunarity"
                category="source"
                paramKey="lacunarity"
                min={1}
                max={4}
                step={0.1}
              />
              <ParamSlider
                label="Octaves"
                category="source"
                paramKey="octaves"
                min={1}
                max={10}
                step={1}
              />
            </div>
          </section>

          <Separator className="bg-border/50" />

          {/* Contours */}
          <section>
            <SectionHeader title="Contours" />
            <div className="flex flex-col gap-3">
              <ParamSlider
                label="Count"
                category="contours"
                paramKey="count"
                min={3}
                max={50}
                step={1}
              />
              <ParamSlider
                label="Step (Interval)"
                category="contours"
                paramKey="step"
                min={0.01}
                max={0.15}
                step={0.005}
                format={(v) => v.toFixed(3)}
              />
              <ParamSlider
                label="Offset"
                category="contours"
                paramKey="offset"
                min={-0.5}
                max={0.5}
                step={0.01}
              />
            </div>
          </section>

          <Separator className="bg-border/50" />

          {/* Geometry */}
          <section>
            <SectionHeader title="Geometry" />
            <div className="flex flex-col gap-3">
              <ParamSlider
                label="Simplify"
                category="geometry"
                paramKey="simplify"
                min={0}
                max={5}
                step={0.1}
              />
              <ParamSlider
                label="Smooth"
                category="geometry"
                paramKey="smooth"
                min={0}
                max={100}
                step={1}
              />
              <ParamSlider
                label="Chamfer"
                category="geometry"
                paramKey="chamfer"
                min={0}
                max={100}
                step={1}
              />
              <ParamSlider
                label="Chamfer Angle"
                category="geometry"
                paramKey="chamferAngle"
                min={30}
                max={170}
                step={1}
                format={(v) => `${v}\u00B0`}
              />
            </div>
          </section>

          <Separator className="bg-border/50" />

          {/* Style */}
          <section>
            <SectionHeader title="Style" />
            <div className="flex flex-col gap-3">
              <ParamSlider
                label="Stroke Width"
                category="style"
                paramKey="strokeWidth"
                min={0.3}
                max={5}
                step={0.1}
                format={(v) => `${v.toFixed(1)}px`}
              />
              <ParamSlider
                label="Width Variation"
                category="style"
                paramKey="strokeWidthVar"
                min={0}
                max={2}
                step={0.05}
              />
              <ParamSlider
                label="Opacity"
                category="style"
                paramKey="opacity"
                min={0.1}
                max={1}
                step={0.01}
                format={(v) => `${Math.round(v * 100)}%`}
              />
            </div>
          </section>

          <Separator className="bg-border/50" />

          {/* Palette */}
          <section>
            <SectionHeader title="Palette" />
            <PaletteSelector />
          </section>
        </div>
      </ScrollArea>
    </div>
  );
}
