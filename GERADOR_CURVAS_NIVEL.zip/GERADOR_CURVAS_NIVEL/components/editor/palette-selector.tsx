"use client";

import { useEditorStore, PALETTES } from "@/lib/store";
import { cn } from "@/lib/utils";

export function PaletteSelector() {
  const paletteId = useEditorStore((s) => s.paletteId);
  const setPaletteId = useEditorStore((s) => s.setPaletteId);
  const setParam = useEditorStore((s) => s.setParam);
  const pushHistory = useEditorStore((s) => s.pushHistory);

  const handleSelect = (id: string) => {
    const palette = PALETTES.find((p) => p.id === id);
    if (!palette) return;
    setPaletteId(id);
    setParam("style", "stroke", palette.strokes[0]);
    pushHistory();
  };

  return (
    <div className="flex flex-col gap-2">
      {PALETTES.map((palette) => (
        <button
          key={palette.id}
          type="button"
          onClick={() => handleSelect(palette.id)}
          className={cn(
            "flex items-center gap-3 rounded-md px-3 py-2 text-left transition-colors",
            paletteId === palette.id
              ? "bg-primary/10 ring-1 ring-primary/30"
              : "hover:bg-secondary",
          )}
        >
          <div className="flex items-center gap-0.5 shrink-0">
            <div
              className="w-4 h-4 rounded-sm border border-border/50"
              style={{ backgroundColor: palette.background }}
            />
            {palette.strokes.slice(0, 4).map((color, i) => (
              <div
                key={i}
                className="w-4 h-4 rounded-sm"
                style={{ backgroundColor: color }}
              />
            ))}
          </div>
          <span className="text-xs text-foreground/80">{palette.name}</span>
        </button>
      ))}
    </div>
  );
}
