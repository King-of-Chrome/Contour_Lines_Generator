"use client";

import { useEditorStore } from "@/lib/store";
import { Toolbar } from "./toolbar";
import { LibraryPanel } from "./library-panel";
import { InspectorPanel } from "./inspector-panel";
import { CanvasRenderer } from "./canvas-renderer";
import {
  ResizablePanelGroup,
  ResizablePanel,
  ResizableHandle,
} from "@/components/ui/resizable";

export function EditorLayout() {
  const leftPanelOpen = useEditorStore((s) => s.leftPanelOpen);
  const rightPanelOpen = useEditorStore((s) => s.rightPanelOpen);

  return (
    <div className="flex flex-col h-screen w-screen">
      <Toolbar />

      <div className="flex-1 overflow-hidden">
        <ResizablePanelGroup direction="horizontal">
          {leftPanelOpen && (
            <>
              <ResizablePanel
                defaultSize={18}
                minSize={14}
                maxSize={28}
                className="min-w-[200px]"
              >
                <LibraryPanel />
              </ResizablePanel>
              <ResizableHandle className="bg-border/50 hover:bg-primary/20 transition-colors" />
            </>
          )}

          <ResizablePanel defaultSize={leftPanelOpen && rightPanelOpen ? 60 : leftPanelOpen || rightPanelOpen ? 78 : 100}>
            <CanvasRenderer />
          </ResizablePanel>

          {rightPanelOpen && (
            <>
              <ResizableHandle className="bg-border/50 hover:bg-primary/20 transition-colors" />
              <ResizablePanel
                defaultSize={22}
                minSize={18}
                maxSize={35}
                className="min-w-[260px]"
              >
                <InspectorPanel />
              </ResizablePanel>
            </>
          )}
        </ResizablePanelGroup>
      </div>
    </div>
  );
}
