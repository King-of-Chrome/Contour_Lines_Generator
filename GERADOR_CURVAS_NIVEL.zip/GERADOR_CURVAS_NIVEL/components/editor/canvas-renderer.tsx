"use client";

import {
  type MouseEvent as ReactMouseEvent,
  useRef,
  useEffect,
  useCallback,
  useState,
} from "react";
import { useEditorStore, PALETTES } from "@/lib/store";
import { runPipeline, scaleContours } from "@/lib/engine/pipeline";
import type { ContourResult } from "@/lib/engine/pipeline";

type Point = [number, number];

export function CanvasRenderer() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const params = useEditorStore((s) => s.params);
  const paletteId = useEditorStore((s) => s.paletteId);
  const camera = useEditorStore((s) => s.camera);
  const setCamera = useEditorStore((s) => s.setCamera);

  const [isPanning, setIsPanning] = useState(false);
  const panStart = useRef({ x: 0, y: 0 });
  const cameraStart = useRef({ panX: 0, panY: 0 });

  // Cache the generated contour data so we only re-generate when params change
  const cachedResult = useRef<{
    result: ContourResult;
    paramsKey: string;
  } | null>(null);
  const rafId = useRef<number>(0);

  const palette = PALETTES.find((p) => p.id === paletteId) ?? PALETTES[0];

  // Build a stable key from the params that affect contour generation
  const paramsKey = JSON.stringify(params);

  // Generate contours (only when params change)
  const getContourData = useCallback(
    (w: number, h: number) => {
      if (cachedResult.current?.paramsKey === paramsKey) {
        return cachedResult.current.result;
      }
      const result = runPipeline(params, w, h);
      cachedResult.current = { result, paramsKey };
      return result;
    },
    [params, paramsKey],
  );

  // Paint to canvas using cached data
  const paint = useCallback(() => {
    const canvas = canvasRef.current;
    const container = containerRef.current;
    if (!canvas || !container) return;

    const rect = container.getBoundingClientRect();
    if (rect.width === 0 || rect.height === 0) return;

    const dpr = window.devicePixelRatio || 1;
    const w = rect.width;
    const h = rect.height;

    if (canvas.width !== Math.round(w * dpr) || canvas.height !== Math.round(h * dpr)) {
      canvas.width = Math.round(w * dpr);
      canvas.height = Math.round(h * dpr);
      canvas.style.width = `${w}px`;
      canvas.style.height = `${h}px`;
    }

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

    // Background
    ctx.fillStyle = palette.background;
    ctx.fillRect(0, 0, w, h);

    const cam = useEditorStore.getState().camera;

    const result = getContourData(w, h);
    const scaled = scaleContours(
      result.contours,
      result.fieldWidth,
      result.fieldHeight,
      w,
      h,
    );

    // Apply camera transform
    ctx.save();
    ctx.translate(w / 2 + cam.panX, h / 2 + cam.panY);
    ctx.scale(cam.zoom, cam.zoom);
    ctx.translate(-w / 2, -h / 2);

    const strokeColors = palette.strokes;
    const levelArray = result.levels;

    for (let li = 0; li < levelArray.length; li++) {
      const level = levelArray[li];
      const polylines = scaled.get(level);
      if (!polylines) continue;

      const colorIndex = li % strokeColors.length;
      const baseWidth = params.style.strokeWidth;
      const variation = params.style.strokeWidthVar;
      const depth = levelArray.length > 1 ? li / (levelArray.length - 1) : 0.5;
      const lineWidth = baseWidth + variation * (1 - depth);

      ctx.strokeStyle = strokeColors[colorIndex];
      ctx.lineWidth = lineWidth;
      ctx.globalAlpha = params.style.opacity * (0.4 + 0.6 * depth);
      ctx.lineJoin = "round";
      ctx.lineCap = "round";

      for (const line of polylines) {
        if (line.length < 2) continue;
        ctx.beginPath();
        ctx.moveTo(line[0][0], line[0][1]);
        for (let i = 1; i < line.length; i++) {
          ctx.lineTo(line[i][0], line[i][1]);
        }
        ctx.stroke();
      }
    }

    ctx.restore();
    ctx.globalAlpha = 1;
  }, [params, palette, getContourData]);

  // Schedule a paint on requestAnimationFrame
  const scheduleRepaint = useCallback(() => {
    cancelAnimationFrame(rafId.current);
    rafId.current = requestAnimationFrame(() => {
      paint();
    });
  }, [paint]);

  // Repaint whenever params/palette/camera change
  useEffect(() => {
    scheduleRepaint();
    return () => cancelAnimationFrame(rafId.current);
  }, [scheduleRepaint, camera]);

  // Repaint on resize
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const observer = new ResizeObserver(() => {
      // Invalidate cache on resize since field dimensions change
      cachedResult.current = null;
      scheduleRepaint();
    });
    observer.observe(container);
    return () => observer.disconnect();
  }, [scheduleRepaint]);

  // Mouse wheel zoom (non-passive listener for preventDefault)
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      const delta = e.deltaY > 0 ? 0.92 : 1.08;
      const currentZoom = useEditorStore.getState().camera.zoom;
      const newZoom = Math.max(0.1, Math.min(10, currentZoom * delta));
      setCamera({ zoom: newZoom });
    };

    container.addEventListener("wheel", onWheel, { passive: false });
    return () => container.removeEventListener("wheel", onWheel);
  }, [setCamera]);

  const handleMouseDown = useCallback(
    (e: ReactMouseEvent) => {
      if (e.button === 1 || (e.button === 0 && e.altKey)) {
        setIsPanning(true);
        panStart.current = { x: e.clientX, y: e.clientY };
        cameraStart.current = { panX: camera.panX, panY: camera.panY };
        e.preventDefault();
      }
    },
    [camera.panX, camera.panY],
  );

  const handleMouseMove = useCallback(
    (e: ReactMouseEvent) => {
      if (!isPanning) return;
      const dx = e.clientX - panStart.current.x;
      const dy = e.clientY - panStart.current.y;
      setCamera({
        panX: cameraStart.current.panX + dx,
        panY: cameraStart.current.panY + dy,
      });
    },
    [isPanning, setCamera],
  );

  const handleMouseUp = useCallback(() => {
    setIsPanning(false);
  }, []);

  return (
    <div
      ref={containerRef}
      className="relative flex-1 h-full w-full overflow-hidden bg-canvas"
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onMouseLeave={handleMouseUp}
      style={{ cursor: isPanning ? "grabbing" : "crosshair" }}
    >
      <canvas ref={canvasRef} className="absolute inset-0" />

      {/* Zoom indicator */}
      <div className="absolute bottom-3 right-3 flex items-center gap-2 rounded-md bg-secondary/80 px-2.5 py-1 text-xs font-mono text-muted-foreground backdrop-blur-sm">
        {Math.round(camera.zoom * 100)}%
      </div>

      {/* Pan hint */}
      <div className="absolute bottom-3 left-3 text-xs text-muted-foreground/50 select-none">
        Alt+Drag to pan / Scroll to zoom
      </div>
    </div>
  );
}
