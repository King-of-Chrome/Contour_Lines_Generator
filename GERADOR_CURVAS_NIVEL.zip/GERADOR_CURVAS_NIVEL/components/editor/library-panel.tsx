"use client";

import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { useEditorStore, PRESETS, PALETTES } from "@/lib/store";
import { cn } from "@/lib/utils";
import { Mountain, Layers, Compass } from "lucide-react";

export function LibraryPanel() {
  const loadPreset = useEditorStore((s) => s.loadPreset);
  const currentParams = useEditorStore((s) => s.params);

  return (
    <div className="flex flex-col h-full bg-card border-r border-border">
      <div className="flex items-center gap-2 px-4 py-3 border-b border-border">
        <Compass className="w-4 h-4 text-primary" />
        <h2 className="text-sm font-semibold text-foreground">Library</h2>
      </div>

      <ScrollArea className="flex-1">
        <div className="flex flex-col gap-4 p-4">
          {/* Presets Section */}
          <section>
            <h3 className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground/70 mb-3">
              Presets
            </h3>
            <div className="flex flex-col gap-2">
              {PRESETS.map((preset) => {
                const palette = PALETTES.find(
                  (p) => p.id === preset.paletteId,
                );
                const isActive =
                  currentParams.source.seed === preset.params.source.seed &&
                  currentParams.source.warp === preset.params.source.warp;

                return (
                  <button
                    key={preset.id}
                    type="button"
                    onClick={() => loadPreset(preset)}
                    className={cn(
                      "group flex flex-col gap-1.5 rounded-lg p-3 text-left transition-all",
                      isActive
                        ? "bg-primary/10 ring-1 ring-primary/30"
                        : "hover:bg-secondary",
                    )}
                  >
                    <div className="flex items-center gap-2">
                      <div
                        className="w-8 h-8 rounded-md flex items-center justify-center"
                        style={{
                          backgroundColor: palette?.background ?? "#0e1014",
                        }}
                      >
                        <Mountain
                          className="w-4 h-4"
                          style={{ color: palette?.strokes[0] ?? "#e8e4dc" }}
                        />
                      </div>
                      <div className="flex flex-col min-w-0">
                        <span className="text-xs font-medium text-foreground truncate">
                          {preset.name}
                        </span>
                        <span className="text-[10px] text-muted-foreground truncate">
                          {preset.description}
                        </span>
                      </div>
                    </div>

                    {/* Mini palette preview */}
                    <div className="flex items-center gap-0.5 ml-10">
                      {palette?.strokes.slice(0, 5).map((color, i) => (
                        <div
                          key={i}
                          className="w-3 h-3 rounded-sm"
                          style={{ backgroundColor: color }}
                        />
                      ))}
                    </div>
                  </button>
                );
              })}
            </div>
          </section>

          <Separator className="bg-border/50" />

          {/* Quick Info */}
          <section>
            <h3 className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground/70 mb-3">
              About
            </h3>
            <div className="rounded-lg bg-secondary/50 p-3">
              <div className="flex items-center gap-2 mb-2">
                <Layers className="w-3.5 h-3.5 text-primary" />
                <span className="text-xs font-medium text-foreground">
                  Contour Generator
                </span>
              </div>
              <p className="text-[11px] leading-relaxed text-muted-foreground">
                Generate topographic contour line graphics with procedural noise.
                Adjust parameters in the inspector to shape terrain, control
                density, smoothing, and chamfering for that signature Jeep
                adventure aesthetic.
              </p>
            </div>
          </section>

          <section>
            <h3 className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground/70 mb-3">
              Shortcuts
            </h3>
            <div className="flex flex-col gap-1.5 text-[11px] text-muted-foreground">
              <div className="flex items-center justify-between">
                <span>Pan canvas</span>
                <span className="font-mono text-foreground/50">Alt + Drag</span>
              </div>
              <div className="flex items-center justify-between">
                <span>Zoom</span>
                <span className="font-mono text-foreground/50">Scroll</span>
              </div>
              <div className="flex items-center justify-between">
                <span>Undo</span>
                <span className="font-mono text-foreground/50">Ctrl+Z</span>
              </div>
              <div className="flex items-center justify-between">
                <span>Redo</span>
                <span className="font-mono text-foreground/50">Ctrl+Shift+Z</span>
              </div>
            </div>
          </section>
        </div>
      </ScrollArea>
    </div>
  );
}
