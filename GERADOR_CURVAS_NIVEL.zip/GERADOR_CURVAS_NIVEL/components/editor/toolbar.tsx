"use client";

import { useEditorStore, PALETTES } from "@/lib/store";
import { Button } from "@/components/ui/button";
import {
  Undo2,
  Redo2,
  Download,
  PanelLeftClose,
  PanelLeftOpen,
  PanelRightClose,
  PanelRightOpen,
  FileImage,
  FileCode2,
  Mountain,
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { exportSVG, downloadSVG } from "@/lib/engine/export";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { useCallback, useEffect } from "react";

export function Toolbar() {
  const undo = useEditorStore((s) => s.undo);
  const redo = useEditorStore((s) => s.redo);
  const historyIndex = useEditorStore((s) => s.historyIndex);
  const historyLength = useEditorStore((s) => s.history.length);
  const leftPanelOpen = useEditorStore((s) => s.leftPanelOpen);
  const rightPanelOpen = useEditorStore((s) => s.rightPanelOpen);
  const toggleLeftPanel = useEditorStore((s) => s.toggleLeftPanel);
  const toggleRightPanel = useEditorStore((s) => s.toggleRightPanel);
  const params = useEditorStore((s) => s.params);
  const paletteId = useEditorStore((s) => s.paletteId);
  const isGenerating = useEditorStore((s) => s.isGenerating);

  const palette = PALETTES.find((p) => p.id === paletteId) ?? PALETTES[0];

  const handleExportSVG = useCallback(() => {
    const svg = exportSVG(params, palette, 1920, 1080);
    downloadSVG(svg, "topoforge-contours.svg");
  }, [params, palette]);

  const handleExportPNG = useCallback(() => {
    // Get the canvas from the DOM and export it
    const canvas = document.querySelector("canvas");
    if (!canvas) return;
    canvas.toBlob((blob) => {
      if (!blob) return;
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "topoforge-contours.png";
      a.click();
      URL.revokeObjectURL(url);
    }, "image/png");
  }, []);

  // Keyboard shortcuts
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === "z") {
        e.preventDefault();
        if (e.shiftKey) redo();
        else undo();
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [undo, redo]);

  return (
    <TooltipProvider delayDuration={300}>
      <header className="flex items-center justify-between h-12 px-3 bg-toolbar border-b border-border">
        {/* Left group */}
        <div className="flex items-center gap-2">
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="sm"
                onClick={toggleLeftPanel}
                className="h-8 w-8 p-0 text-muted-foreground hover:text-foreground"
              >
                {leftPanelOpen ? (
                  <PanelLeftClose className="w-4 h-4" />
                ) : (
                  <PanelLeftOpen className="w-4 h-4" />
                )}
                <span className="sr-only">Toggle library panel</span>
              </Button>
            </TooltipTrigger>
            <TooltipContent>Toggle Library</TooltipContent>
          </Tooltip>

          <div className="h-5 w-px bg-border" />

          <div className="flex items-center gap-1.5">
            <Mountain className="w-4 h-4 text-primary" />
            <span className="text-sm font-semibold text-foreground tracking-tight">
              TopoForge
            </span>
          </div>

          {isGenerating && (
            <div className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse ml-2" />
          )}
        </div>

        {/* Center group */}
        <div className="flex items-center gap-1">
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="sm"
                onClick={undo}
                disabled={historyIndex <= 0}
                className="h-8 w-8 p-0 text-muted-foreground hover:text-foreground disabled:opacity-30"
              >
                <Undo2 className="w-4 h-4" />
                <span className="sr-only">Undo</span>
              </Button>
            </TooltipTrigger>
            <TooltipContent>Undo (Ctrl+Z)</TooltipContent>
          </Tooltip>

          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="sm"
                onClick={redo}
                disabled={historyIndex >= historyLength - 1}
                className="h-8 w-8 p-0 text-muted-foreground hover:text-foreground disabled:opacity-30"
              >
                <Redo2 className="w-4 h-4" />
                <span className="sr-only">Redo</span>
              </Button>
            </TooltipTrigger>
            <TooltipContent>Redo (Ctrl+Shift+Z)</TooltipContent>
          </Tooltip>
        </div>

        {/* Right group */}
        <div className="flex items-center gap-2">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="default"
                size="sm"
                className="h-8 gap-1.5 text-xs bg-primary text-primary-foreground hover:bg-primary/90"
              >
                <Download className="w-3.5 h-3.5" />
                Export
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-44">
              <DropdownMenuItem onClick={handleExportSVG}>
                <FileCode2 className="w-4 h-4 mr-2" />
                Export SVG
              </DropdownMenuItem>
              <DropdownMenuItem onClick={handleExportPNG}>
                <FileImage className="w-4 h-4 mr-2" />
                Export PNG
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          <div className="h-5 w-px bg-border" />

          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="sm"
                onClick={toggleRightPanel}
                className="h-8 w-8 p-0 text-muted-foreground hover:text-foreground"
              >
                {rightPanelOpen ? (
                  <PanelRightClose className="w-4 h-4" />
                ) : (
                  <PanelRightOpen className="w-4 h-4" />
                )}
                <span className="sr-only">Toggle inspector panel</span>
              </Button>
            </TooltipTrigger>
            <TooltipContent>Toggle Inspector</TooltipContent>
          </Tooltip>
        </div>
      </header>
    </TooltipProvider>
  );
}
