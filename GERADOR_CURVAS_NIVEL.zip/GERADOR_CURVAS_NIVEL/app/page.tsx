import { EditorLayout } from "@/components/editor/editor-layout";

export default function Page() {
  return <EditorLayout />;
}
